//THIS CODE WILL CREATE A JSON FILE WITH THE REQUIRED DATA IN IT AND CONVERT IT TO A BASE64

import java.text.SimpleDateFormat;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import groovy.json.JsonBuilder;

def Attributes_Name = job.getAttributeValues("Sn_Attributes_Name")
def Attributes_Value = job.getAttributeValues("Sn_Attributes_Value")
String AttributesTemp;

Date now = new Date()

SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

def creationtime = timestamp.format(now);

def builder = new groovy.json.JsonBuilder()
        def root = builder{           
               origin job.getAttribute("Sn_Origin")
			   forceUnique false
               docSubType job.getAttribute("Sn_docSubType")
               channel job.getAttribute("Sn_channel")
			  

       }
 AttributesTemp = '{"name": "logicalGroupCount","value": "1"},{"name": "createdOrScannedDateTime","value": "'+creationtime+'"},{"name": "logicalGroupId","value": "'+job.getAttribute("Sn_Extid_Value")+'"},{"name": "numberOfPages","value": ""},{"name": "primaryEntity","value": "'+job.getAttribute("Sn_Extid_Value")+'"},{"name": "approverDate","value": ""},{"name": "approver","value": ""},{"name": "docName","value": "'+job.getAttribute("DB_ArtefactName")+'"},{"name": "emailFrom","value": "'+job.getAttribute("DB_FromEmailAddress")+'"},{"name": "emailSubject","value": "'+job.getAttribute("DB_generalEmail")+'"},{"name": "correlationId","value": "'+job.getAttribute("Sn_OCM_CorrelationID")+'"}'
//println("AttributesTemp2="+AttributesTemp)
AttributesTemp = ',"'+"attributes"+'":[' +AttributesTemp + "]"
println("AttributesTemp3="+AttributesTemp)
String JsonString = builder.toString();
int lstind = JsonString.lastIndexOf('}');

String JSON = JsonString.substring(0,lstind) + AttributesTemp + "}" ;   
println(JSON)
def Jsonbase64 = new ArrayList()
String Jsonbase64str = JSON.bytes.encodeBase64().toString();

job.setAttribute("Sn_JSONBase64",Jsonbase64str);

println("base64="+Jsonbase64str)
      
         