//DATABASE OPERATION SELECT QUERY

import groovy.io.FileType;
import java.nio.charset.*
import java.io.IOException;
import groovy.sql.Sql

def db = [url:'jdbc:ASDF:sqlserver://dkfoenskof/dbtest', user:'admin', password:'pass', driver:'net.sourceforge.ASADF.jdbc.Driver']
def sql = Sql.newInstance(db.url, db.user, db.password, db.driver)
def attachmentsname = []
def res = new ArrayList()

attachmentsname = job."_Attachments";

println(attachmentsname.size())
def Filename = attachmentsname[0]
println(Filename)
 
for (int i = 0; i < attachmentsname.size(); i++)
{
res = sql.rows("""
DECLARE
@SourceSystem VARCHAR(20)=${job._ReqSystem}, 
@requirementItem VARCHAR(50)= ${attachmentsname[i]};

SELECT [SourceSystem]
      ,[requirementItem]
      ,[ArtefactID]
      ,[ArtefactType]
      ,[ArtefactName]
      ,[isCoreDoc]
      ,[isDocument]
      ,[ArtefactLocation]
      ,[DocSubTypeCode]
      ,[DocSubTypeDescription]
      ,[openingHourText]
      ,[entity]
      ,[ABN]
      ,[AFSL]
      ,[DataOutputExtension]
  FROM [dbo].[ArtifactReqAt]
  WHERE
  SourceSystem=@SourceSystem AND 
  requirementItem=@requirementItem
      """)
//assert rows.size() == 3
job."_ArtefactLocation" = res.collect{it.ArtefactLocation}
job."_DocSubTypeCode" = res.collect{it.DocSubTypeCode}
job."_DocSubTypeDescription" = res.collect{it.DocSubTypeDescription}

println(job."_ArtefactLocation")
//job."_ArtefactLocation" = "icm://Interactive//MasterTemplates/NPAS/Questionnaire_Master.wfd"
job.addDocument(attachmentsname[i]+","+job."_ArtefactLocation", "RequirementsFile");
}
