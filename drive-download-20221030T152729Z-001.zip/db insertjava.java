//READING THE VALUES FROM XML TO LOCAL varialbes AND INSERTING INTO DB


import groovy.io.FileType;
import java.nio.charset.*
import java.io.IOException;
import groovy.sql.Sql
import java.io.*;
import groovy.xml.MarkupBuilder;
import java.util.*;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;

def srcPayload =  new File(server.'job_spool_location' + "/slot" + job.'job-spool-slot' + "/" + job.'job-identifier'+'/1/Payload.xml')
def PayloadDocuments = new XmlSlurper().parse(srcPayload);

String OutboundCommunicationID,requestType,CorrelationID,DeliveryChannel
OutboundCommunicationID = job.'DB_CommunicationID'
requestorSytem = job."ReqSystem"
requestType = job."Jobtype"
CorrelationID = job."CorrelationID"
DeliveryChannel = job."DeliveryChannel"

//DB definition
def db = [url:server.'Database_URL', user:server.'Database_User', password:server.'Database_Password', driver:server.'Database_Driver']
def sql = Sql.newInstance(db.url, db.user, db.password, db.driver)



	
	println(InboundCommunicationID+","+OutboundCommunicationID+","+requestorSytem+","+requestType+","+CorrelationID+","+","+DeliveryChannel+","+qrCode)

sql.execute("""
						INSERT INTO [dbo].[InboundCommunication]
							(
							[InboundCommunicationID]
							,[OutboundCommunicationID]
							,[requestorSytem]
							,[requestType]
							,[CorrelationID]
							,[RecipientID]
							,[DeliveryChannel]
							,[qrCode]
							)
						VALUES		
							(
							'${InboundCommunicationID}'
							,'${OutboundCommunicationID}'
							,'${requestorSytem}'
							,'${requestType}'
							,'${CorrelationID}'
							,''
							,'${DeliveryChannel}'
							,'${qrCode}'
							)
						""");
						
				
			}
	}
		


		
		//ins barcode npas SJ