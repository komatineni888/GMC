//THIS WILL READ THE XML FILE ("Input.xml") AND STORE THE VALUES FROM THE XML INTO LOCAL VARIABLES OR JOB VARIABLES

import java.io.*;
import java.util.*;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
String RequestType,BatchName,JSONBase64,CorrelationID,TemplateID,DeliveryPoint;

def g = new File("D:/Quadient/InspireAutomation/spool/slot" + job."job-spool-slot" + "/" + job.'job-identifier' + "/Input.xml")


try{
	//Missing payload check
	Documents = new XmlSlurper().parseText(g.text)
	
	//Extract Request Type ,Communication Request Count and Correlation Id 
	RequestType = Documents.JobHeader.RequestorSystem.text()
	BatchName = Documents.ReferenceData.BatchName.text()
	JSONBase64 = Documents.ReferenceData.JSONBASE64.text()
	CorrelationID = Documents.'Array-cr'.cr.Template.CorrelationID.text()
	TemplateID = Documents.'Array-cr'.cr.Template.TemplateID.text()

	job.setAttribute("CorrelationID",CorrelationID);
	job.setAttribute("TemplateID",TemplateID);
	job.setAttribute("ReqSystem",RequestType);
	job.setAttribute("_JSONBase64",JSONBase64);
	job.setAttribute("DeliveryPoint","email");
	}
catch(all)
	{
	returncode = "123234";
	job."Error_Response" = Response.Test1.ResponseCreation(category,returncode,JobID,CorrelationID,TicketID,TicketURL);
	job.cancel("Invalid job request,Invalid SOAP request");
	}