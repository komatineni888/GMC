//THIS CODE WILL ZIP ALL THE FILES INSIDE "EMAIL" FOLDER

import java.util.zip.ZipOutputStream  
import java.util.zip.ZipEntry  
import java.nio.channels.FileChannel  

public static void addDirToZipArchive(ZipOutputStream zos, File fileToZip, String parrentDirectoryName) throws Exception {
    if (fileToZip == null || !fileToZip.exists()) {
        return;
    }

    String zipEntryName = fileToZip.getName();
	//println(" 1  " + zipEntryName);
    if (parrentDirectoryName!=null && !parrentDirectoryName.isEmpty() ) {
        zipEntryName = parrentDirectoryName + "/" + fileToZip.getName();
		println(" 1  " + zipEntryName);
    }

    if (fileToZip.isDirectory()) 
	{
       // println("2" + zipEntryName);
        for (File file : fileToZip.listFiles()) 
		{
            addDirToZipArchive(zos, file, zipEntryName);
        }
    } 
	else 
	{
        //println(" 3  " + zipEntryName);
        byte[] buffer = new byte[1024];
        FileInputStream fis = new FileInputStream(fileToZip);
       zos.putNextEntry(new ZipEntry(zipEntryName));
        int length;
        while ((length = fis.read(buffer)) > 0) 
		{
            zos.write(buffer, 0, length);
        }
        zos.closeEntry();
        fis.close();
    }
}

public static void main(String[] args) throws Exception {
    FileOutputStream fos = new FileOutputStream("C:/OUTPUT/" + job.'_ReqSystem' + "_" + job.'_DeliveryPoint' + "_" + job.'_Timestamp' + "_OD_Batch_" + job.'_TemplateID' + ".zip")
	println("D:/Quadient/InspireAutomation/spool/slot" + job.'job-spool-slot' + "/" + job.'job-identifier'  + job.'_ReqSystem' + "_" + job.'_DeliveryPoint' + "_" + job.'_Timestamp' + "_IN_Batch_" + job.'_TemplateID' + ".zip")
    ZipOutputStream zos = new ZipOutputStream(fos);
    addDirToZipArchive(zos, new File("D:/Quadient/InspireAutomation/spool/slot" + job.'job-spool-slot' + "/" + job.'job-identifier' + "/EMAIL"), null);
    zos.flush();
    fos.flush();
    zos.close();
    fos.close();
}