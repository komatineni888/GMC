var d = new Date();
var dateformatted = (d.getMonth()+1).toString() +"_"+ d.getDate().toString() +"_"+d.getFullYear().toString()
setvar("DateFormatted", dateformatted)
console.log("dateformatted==="+dateformatted)
