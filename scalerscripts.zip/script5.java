var destination = getvar("destination")
var jobID = getvar("sys.job-id")
var started = getvar("sys.job-started")
var priority = getvar("sys.job-priority")
var BatchID = getvar("BatchID")
var jobLogHTML = getvar("jobLogHTML")
var jobLogTNO = getvar("jobLogTNO")
var jobLogPDF = getvar("jobLogPDF")
var tab = "\n"

 console.log("jobLogHTML=="+jobLogHTML)
  console.log("jobLogTNO=="+jobLogTNO)
  console.log("jobLogPDF=="+jobLogPDF)

if(!fs.isFile(destination))
{
    var file = fs.write(destination, "The job " + jobID + " with priority " + priority + " submitted at " + started + " was processed succesfully." + tab, "UTF-8")
}
else
{
    var file = fs.append(destination, "The job " + jobID + " with priority " + priority + " submitted at " + started + " was processed succesfully." + tab, "UTF-8")
}

var confirmation = "The log file for job " + jobID + " was created in " + destination
setvar("confirmation", confirmation)


//generating confirmation file for the sucessfull jobs
if (jobLogHTML=="true")
{
    var path = "C:" + fs.separator() + "Production" +fs.separator()+BatchID+".html.ok"
	var file = fs.append(path, "OK", "UTF-8")
}
if (jobLogTNO=="true")
{
   var path = "C:" + fs.separator() + "Production" +fs.separator()+BatchID+".tno.ok"
	var file = fs.append(path, "OK", "UTF-8")
}
if (jobLogPDF=="true")
{
	var path = "C:" + fs.separator() + "Production" +fs.separator()+BatchID+".pdf.ok"
	var file = fs.append(path, "OK", "UTF-8")
}

