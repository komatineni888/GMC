     job.setPriority(90)

if (!env.create('Initials', 'KP')) {
job.fail('Unable to create environment variable.')
} else {
console.info('Environment variable was successfully created.')
}


