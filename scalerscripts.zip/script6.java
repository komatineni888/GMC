

var reportFile = "E:" + fs.separator() + "Desktop" + fs.separator() + "SK"+fs.separator()+"note.csv"
var cnt = 0;
var contents = fs.readLines(reportFile, function(line) {
   //  console.log("line=="+line)
    if(cnt==0)
    {
    //  console.log("HEADER")
    }
    else
    {
      // console.log("splitting")
       var temp = line.split('|');
       setvar("templateid", temp[0])
        console.log("templateid:=="+temp[0])
        console.log("WFDPath:=="+temp[1])
        console.log("BatchID:=="+temp[2])
    }
    cnt++;
});