//var jobID = getvar("sys.job-id")
//file operations

var path = "C:" + fs.separator() + "Users" + fs.separator() + "kolli"+fs.separator()+"Desktop"+ fs.separator()+"Q_1";
console.log("path: " + path)

if (fs.isDirectory(path))
{
 console.log("inside if path: " + path) 
 var info = fs.list(path);
for (i = 0; i < info.length; i++) {
    console.log("filename :"+info[i].name);
    
    var filename = info[i].name;
    var filenamePart = filename.split("_",1);
    var filenamelenght = filenamePart.toString().length;
    console.log("Lenght =="+filenamelenght);
    console.log("filenamePart" + filenamePart)
    var movepath = "C:" + fs.separator() + "Users" + fs.separator() + "kolli"+fs.separator()+"Desktop"+ fs.separator()+"Q_3"+ fs.separator()+ filenamePart;
    if (!fs.exists(movepath))
    {
        console.log("exist if")
    fs.mkdirs(movepath)
    }
    if (info[i].name.substring(0,filenamelenght) == filenamePart)
    {
      var sourcefile = path+fs.separator()+info[i].name;
      console.log(sourcefile)
      
      var destfile = movepath+fs.separator()+info[i].name;
      console.log(destfile)
       console.log("Files before moved")
      //fs.move()(sourcefile,destfile )
      fs.copy(sourcefile,destfile )
      console.log("Files moved to respected folders")
    }
    
    
    
}   
}