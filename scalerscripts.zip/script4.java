var jobID = getvar("sys.job-id")
var path = "C:" + fs.separator() + "Production" + fs.separator() + "ErrorLog.log"
console.log("path: " + path)
var tab = "\n\n"
var log1, log2, log3
var started = getvar("sys.job-started")

/*console.log("JOBLOG")
 console.log("*******************jobLogHTML*******************"+getvar("jobLogHTML"))
  console.log("*******************jobLogTNO*******************"+getvar("jobLogTNO"))
  console.log("*******************jobLogPDF*******************"+getvar("jobLogPDF"))*/

//executes any if any one document creator errors out
if (!isvar("jobLogHTML") || !isvar("jobLogPDF") || !isvar("jobLogTNO")) 
{
    console.log("executes any if any one document creator errors out")
    var file = fs.write(path, "***********************Error Logs***********************" + tab, "UTF-8")

    if (!isvar("jobLogHTML")) {
        log1 = "Error in HTML production" + " submitted at " + started + " with jobID " + jobID
        var file = fs.append(path, "**HTML Document Creator**" + tab, "UTF-8")
        var file = fs.append(path, log1 + tab, "UTF-8")
        setvar("jobLogHTML_ok", "false")
    } else {
        setvar("jobLogHTML_ok", "true")
    }
    
    
    if (!isvar("jobLogTNO")) {
        log2 = "Error in TNO production" + " submitted at " + started + " with jobID " + jobID
        var file = fs.append(path, "**TNO Document Creator**" + tab, "UTF-8")
        var file = fs.append(path, log2 + tab, "UTF-8")
        setvar("jobLogTNO_ok", "false")
    } else {
        setvar("jobLogTNO_ok", "true")
    }
    
    
    if (!isvar("jobLogPDF")) {
         console.log("1")
        log3 = "Error in PDF production" + " submitted at " + started + " with jobID " + jobID
        var file = fs.append(path, "**PDF Document Creator**" + tab, "UTF-8")
        var file = fs.append(path, log3, "UTF-8")
        setvar("jobLogPDF_ok", "false")
    } else {
         console.log("2")
        setvar("jobLogPDF_ok", "true")
        
    }
} else 
{
    console.log("ALL 3 SUCCESFULL")
    setvar("jobLogHTML_ok", "true")
    setvar("jobLogTNO_ok", "true")
    setvar("jobLogPDF_ok", "true")
}

var logDestination = "C:" + fs.separator() + "Production" + fs.separator() + "Spoollogfile.log"
setvar("destinationPath", logDestination)

setvar("FinalLogContent", "Documents for this office were processed.")

console.log("*******************JOBLOGok*******************")
 console.log("jobLogHTML_ok=="+getvar("jobLogHTML_ok"))
  console.log("jobLogTNO_ok=="+getvar("jobLogTNO_ok"))
  console.log("jobLogPDF_ok=="+getvar("jobLogPDF_ok"))


